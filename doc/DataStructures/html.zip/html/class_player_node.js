var class_player_node =
[
    [ "PlayerNode", "class_player_node.html#a63c3a6dc6381dc94579c7b89a1fc95d7", null ],
    [ "PlayerNode", "class_player_node.html#ac9e2a1846dd92aa7f6f1b1c4c01390df", null ],
    [ "getData", "class_player_node.html#a02617035fbc87769e98ceca545db8fca", null ],
    [ "getNext", "class_player_node.html#a47e7e7da725be6ffc11a8d6af0903a26", null ],
    [ "setData", "class_player_node.html#aff4dd4b14143f0003c85d7cb489dc660", null ],
    [ "setNext", "class_player_node.html#a94c98c6b9f174a4b7325559a5dd144cd", null ]
];