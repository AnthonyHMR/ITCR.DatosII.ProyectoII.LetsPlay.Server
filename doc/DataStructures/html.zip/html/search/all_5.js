var searchData=
[
  ['playernode_6',['PlayerNode',['../class_player_node.html',1,'PlayerNode'],['../class_player_node.html#a63c3a6dc6381dc94579c7b89a1fc95d7',1,'PlayerNode::PlayerNode(Player *data, PlayerNode *next)'],['../class_player_node.html#ac9e2a1846dd92aa7f6f1b1c4c01390df',1,'PlayerNode::PlayerNode(Player *data)']]]
];
