var searchData=
[
  ['setdata_18',['setData',['../class_player_node.html#aff4dd4b14143f0003c85d7cb489dc660',1,'PlayerNode']]],
  ['setnext_19',['setNext',['../class_player_node.html#a94c98c6b9f174a4b7325559a5dd144cd',1,'PlayerNode']]]
];
