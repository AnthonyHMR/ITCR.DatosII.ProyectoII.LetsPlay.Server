var annotated_dup =
[
    [ "Backtracking", "class_backtracking.html", "class_backtracking" ],
    [ "JsonParser", "class_json_parser.html", "class_json_parser" ],
    [ "Location", "struct_location.html", "struct_location" ],
    [ "Node", "class_node.html", "class_node" ],
    [ "NodeComparator", "struct_node_comparator.html", "struct_node_comparator" ],
    [ "PathfindingAStar", "class_pathfinding_a_star.html", "class_pathfinding_a_star" ],
    [ "Player", "class_player.html", "class_player" ],
    [ "StarNode", "class_star_node.html", "class_star_node" ]
];