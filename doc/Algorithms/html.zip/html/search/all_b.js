var searchData=
[
  ['readgamesetup_19',['readGameSetUp',['../class_json_parser.html#a31ae1c7c74ce3b8e00e0acd046529701',1,'JsonParser']]]
];
