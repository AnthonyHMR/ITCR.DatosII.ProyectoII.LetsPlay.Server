var searchData=
[
  ['location_13',['Location',['../struct_location.html',1,'']]]
];
