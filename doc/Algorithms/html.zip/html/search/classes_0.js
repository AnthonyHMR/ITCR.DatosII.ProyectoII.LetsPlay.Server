var searchData=
[
  ['backtracking_28',['Backtracking',['../class_backtracking.html',1,'']]]
];
