var indexSectionsWithContent =
{
  0: "abcefgijlnprsw",
  1: "bjlnps",
  2: "abcefgiprsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

