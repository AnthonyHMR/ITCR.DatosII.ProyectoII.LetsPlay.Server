var searchData=
[
  ['backtracking_1',['Backtracking',['../class_backtracking.html',1,'Backtracking'],['../class_backtracking.html#ac751fb4287bd47725ac89822cb988344',1,'Backtracking::Backtracking()']]]
];
