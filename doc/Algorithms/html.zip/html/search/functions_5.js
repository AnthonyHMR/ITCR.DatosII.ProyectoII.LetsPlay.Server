var searchData=
[
  ['getid_43',['getId',['../class_player.html#a69ee7ea24ebba0be1ab3c7157e7c5ffa',1,'Player']]],
  ['getposx_44',['getPosX',['../class_player.html#a1855ae5f29f7f22a4699733692e48fce',1,'Player']]],
  ['getposy_45',['getPosY',['../class_player.html#a06487efec49f46828c3167bbe122bde7',1,'Player']]],
  ['getteam_46',['getTeam',['../class_player.html#ac8f4169480e5b2b1b853a0b3de1ac8b5',1,'Player']]]
];
