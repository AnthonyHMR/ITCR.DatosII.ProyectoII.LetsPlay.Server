var searchData=
[
  ['location_30',['Location',['../struct_location.html',1,'']]]
];
