var searchData=
[
  ['backtracking_37',['Backtracking',['../class_backtracking.html#ac751fb4287bd47725ac89822cb988344',1,'Backtracking']]]
];
