var class_player =
[
    [ "getId", "class_player.html#a69ee7ea24ebba0be1ab3c7157e7c5ffa", null ],
    [ "getPosX", "class_player.html#a1855ae5f29f7f22a4699733692e48fce", null ],
    [ "getPosY", "class_player.html#a06487efec49f46828c3167bbe122bde7", null ],
    [ "getTeam", "class_player.html#ac8f4169480e5b2b1b853a0b3de1ac8b5", null ],
    [ "setId", "class_player.html#ac1d9e36a65885e08731baaee99d2e0d0", null ],
    [ "setPosX", "class_player.html#afd7ab90d410c305e6ef94a3f0512b0b9", null ],
    [ "setPosY", "class_player.html#a5b46a17cbe8d77a9a67aa412328c9670", null ],
    [ "setTeam", "class_player.html#a98992036f1fc1e04bdc672b1951c886b", null ]
];