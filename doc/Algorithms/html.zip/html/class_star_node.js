var class_star_node =
[
    [ "StarNode", "class_star_node.html#a929d0d90f3477f47ef355177e6daafc0", null ],
    [ "StarNode", "class_star_node.html#a728391f608dfe0e3722d6ef23070824a", null ],
    [ "F", "class_star_node.html#a56c9be2987eab2c94b7cac58eb14c370", null ],
    [ "G", "class_star_node.html#afbb414e27505dc0cc4b304f8c5802289", null ],
    [ "H", "class_star_node.html#a5da4f4bd04ae41f1a1427b1c4077bd5b", null ],
    [ "parent", "class_star_node.html#a80fe09563425083eb73a7aa39fcce7db", null ],
    [ "safe", "class_star_node.html#a5ee4636b284e7e8375abcb0d666c8747", null ],
    [ "x", "class_star_node.html#ab57d5d7c6aed65defe0d72c59fe6def6", null ],
    [ "y", "class_star_node.html#accc52920e3f697f55881240b0c0c7c06", null ]
];