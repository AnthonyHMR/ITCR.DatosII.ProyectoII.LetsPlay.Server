var struct_location =
[
    [ "Location", "struct_location.html#a87790c14997fd8cdd12080c78c9794bb", null ],
    [ "Location", "struct_location.html#a15f2d304695d85442f6e5ca423814ff1", null ],
    [ "col", "struct_location.html#ae24dbd2ef6885fbe83f34155d6600910", null ],
    [ "row", "struct_location.html#af5cb94dca24df1428362c119c223a4c6", null ]
];