var struct_node_comparator =
[
    [ "operator()", "struct_node_comparator.html#a12a3f491550fd0139d8697f8816c38a6", null ]
];