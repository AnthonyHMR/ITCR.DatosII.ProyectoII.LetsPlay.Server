var searchData=
[
  ['mserver_1',['mServer',['../classm_server.html',1,'mServer'],['../classm_server.html#acc91e4dc651f91ab7eb89a290bde6ad9',1,'mServer::mServer()']]]
];
