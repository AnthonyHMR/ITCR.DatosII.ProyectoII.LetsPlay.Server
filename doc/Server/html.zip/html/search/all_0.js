var searchData=
[
  ['getmessage_0',['getMessage',['../classm_server.html#ae745aecaf493608bf094071bc3a37633',1,'mServer']]]
];
