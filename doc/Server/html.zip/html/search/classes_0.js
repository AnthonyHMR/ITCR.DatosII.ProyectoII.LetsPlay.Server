var searchData=
[
  ['mserver_9',['mServer',['../classm_server.html',1,'']]]
];
