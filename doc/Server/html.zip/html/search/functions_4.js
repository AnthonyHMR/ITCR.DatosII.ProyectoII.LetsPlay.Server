var searchData=
[
  ['searchplayer_15',['searchPlayer',['../classm_server.html#abc29cbfbe941a4f72441af11dc22d0af',1,'mServer']]],
  ['sendmessage_16',['sendMessage',['../classm_server.html#a6f7b34f319a9c90f669d16fd60408ee7',1,'mServer']]],
  ['storeplayerlocation_17',['storePlayerLocation',['../classm_server.html#ae0004100398daf71c5b54245a49385ae',1,'mServer']]]
];
